USE AdventureWorks;

-- property functions - SERVER
SELECT @@SERVERNAME Servername, SERVERPROPERTY('MachineName') MachineName;

SELECT SERVERPROPERTY('Edition') Edition, SERVERPROPERTY('ProductLevel') Level
, SERVERPROPERTY('ProductUpdateLevel') CU, SERVERPROPERTY('ProductUpdateReference') KB;

SELECT SERVERPROPERTY('InstanceDefaultDataPath') DataPath
, SERVERPROPERTY('InstanceDefaultLogPath') LogPath

-- DatabaseProperty
SELECT name, DATABASEPROPERTYEX(name,'IsClone') clone
, DATABASEPROPERTYEX(name,'IsAutoCreateStatistics') auto_create_stats,* FROM sys.databases;

-- OBJECTPROPERTY

SELECT object_id
,name
, OBJECT_NAME(object_id) trigger_name
, OBJECT_NAME(parent_id) table_name
, OBJECTPROPERTYEX(object_id,'ExecIsAfterTrigger') is_after_trigger
from sys.triggers;

exec sp_helptext 'sys.triggers'

-- SQL_VARIANT_PROPERTY -- cool stuff

-- get the type of a column
SELECT TOP 5 BusinessEntityID, SQL_VARIANT_PROPERTY(BusinessEntityID,'BaseType') BaseType
,NationalIDNumber,SQL_VARIANT_PROPERTY(NationalIDNumber,'BaseType') BaseType
,OrganizationLevel,SQL_VARIANT_PROPERTY(OrganizationLevel,'BaseType') BaseType
,BirthDate,SQL_VARIANT_PROPERTY(BirthDate,'BaseType') BaseType
,SalariedFlag,SQL_VARIANT_PROPERTY(SalariedFlag,'BaseType') BaseType
FROM HumanResources.Employee

-- data type of expressions
;WITH cte(PI,A,B,c) AS (SELECT PI(), 3*5, 3*5.0, $3*5)
SELECT 'BaseType' property, SQL_VARIANT_PROPERTY(pi,'BaseType') pi
, SQL_VARIANT_PROPERTY(a,'BaseType') a
, SQL_VARIANT_PROPERTY(b,'BaseType') b
, SQL_VARIANT_PROPERTY(c,'BaseType') c
FROM cte
UNION all
SELECT 'Precision',SQL_VARIANT_PROPERTY(PI(),'Precision') pi
, SQL_VARIANT_PROPERTY(3*5,'Precision') a
, SQL_VARIANT_PROPERTY(3*5.0,'Precision') b
, SQL_VARIANT_PROPERTY($3*5,'Precision') c
FROM cte
UNION all
SELECT 'MaxLength', SQL_VARIANT_PROPERTY(PI(),'MaxLength') pi
, SQL_VARIANT_PROPERTY(3*5,'MaxLength') a
, SQL_VARIANT_PROPERTY(3*5.0,'MaxLength') b
, SQL_VARIANT_PROPERTY($3*5,'MaxLength') c

-- OBJECT_DEFINITION
SELECT OBJECT_DEFINITION(OBJECT_ID('uspGetBillOfMaterials'));
SELECT OBJECT_DEFINITION(OBJECT_ID('sys.triggers'));

-- generate script of all module-based objects
SELECT N'GO
' + definition
FROM sys.sql_modules
