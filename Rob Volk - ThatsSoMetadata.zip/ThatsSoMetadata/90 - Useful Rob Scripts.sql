-- Rob Volk handy procedures
with cte(this,refs_that) AS (
select object_id, referenced_major_id from sys.sql_dependencies WHERE referenced_major_id IS NOT null
union
select referencing_id, referenced_id from sys.sql_expression_dependencies WHERE referenced_id IS NOT NULL
)
SELECT FORMATMESSAGE(N'%s.%s',OBJECT_SCHEMA_NAME(this),OBJECT_NAME(this)) this
, FORMATMESSAGE(N'%s.%s',OBJECT_SCHEMA_NAME(refs_that),OBJECT_NAME(refs_that)) refs_that 
FROM cte
ORDER BY this, refs_that;
GO

USE master;
GO
GO
-- finds all references for an object in the current database
CREATE PROCEDURE sp_ref @obj sql_variant AS
SET NOCOUNT ON;
IF @obj IS NULL RETURN;
DECLARE @o int=CASE 
WHEN CAST(SQL_VARIANT_PROPERTY(@obj,'BaseType') as sysname) LIKE '%char' THEN OBJECT_ID(CAST(@obj as NVARCHAR(517))) 
ELSE CAST(@obj as int) END;

with cte(this,refs_that) AS (
select object_id, referenced_major_id from sys.sql_dependencies where @o in (object_id,referenced_major_id)
union
select referencing_id, referenced_id from sys.sql_expression_dependencies where @o in(referencing_id, referenced_id)
)
SELECT FORMATMESSAGE(N'%s.%s',OBJECT_SCHEMA_NAME(this),OBJECT_NAME(this)) this, FORMATMESSAGE(N'%s.%s',OBJECT_SCHEMA_NAME(refs_that),OBJECT_NAME(refs_that)) refs_that 
FROM cte
ORDER BY this, refs_that;
GO
-- finds cached plan and execution stats for procedure in current database
GO
CREATE PROCEDURE sp_plan @obj nvarchar(512) AS
SET NOCOUNT ON;
select p.query_plan, s.cached_time, s.last_execution_time, s.total_worker_time/s.execution_count/1000.0 avg_time_ms, s.max_worker_time, s.execution_count
from sys.dm_exec_procedure_stats s 
cross apply sys.dm_exec_query_plan(s.plan_handle) p where s.database_id=db_id() and s.object_id=object_id(@obj)
GO
-- mark as system objects to run in any database
EXEC sys.sp_MS_marksystemobject 'sp_ref';
EXEC sys.sp_MS_marksystemobject 'sp_plan';


-- Examples
USE AdventureWorks;
EXEC sp_ref 'dbo.ufnGetAccountingEndDate'
EXEC sp_ref 'HumanResources.uspUpdateEmployeePersonalInfo'

EXEC sp_ref 'Sales.SalesOrderDetailSafe'

-- execute uspGetManagerEmployees 10 with recompile -- or other procedure a few times to populate procedure cache

EXEC sp_plan 'uspGetManagerEmployees'
