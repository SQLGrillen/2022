-- Find constraints in your database
USE AdventureWorks;

-- Domain constraints - data type, nullability, default
SELECT TABLE_NAME, COLUMN_NAME, DATA_TYPE, IS_NULLABLE, COLUMN_DEFAULT
FROM INFORMATION_SCHEMA.COLUMNS
ORDER BY TABLE_NAME, ORDINAL_POSITION

--PRIMARY KEY and UNIQUE constraints
SELECT OBJECT_SCHEMA_NAME(t.object_id) + N'.' + t.name table_name, 
k.name constraint_name, k.type_desc constraint_type
FROM sys.key_constraints k
INNER JOIN sys.tables t ON k.parent_object_id=t.object_id
ORDER BY 1,2

-- CHECK constraints
SELECT OBJECT_SCHEMA_NAME(t.object_id) + N'.' + t.name table_name, 
cc.name constraint_name, cc.definition, cc.is_not_trusted
FROM sys.check_constraints cc
INNER JOIN sys.tables t ON cc.parent_object_id=t.object_id
ORDER BY 1,2,3

-- DEFAULT constraints
SELECT OBJECT_SCHEMA_NAME(t.object_id) + N'.' + t.name table_name, 
d.name constraint_name, COL_NAME(d.parent_object_id, d.parent_column_id) column_name, d.definition
FROM sys.default_constraints d
INNER JOIN sys.tables t ON d.parent_object_id=t.object_id

-- FOREIGN KEY constraints
SELECT OBJECT_SCHEMA_NAME(t1.object_id) + N'.' + t1.name table_name, 
fk.name constraint_name, OBJECT_SCHEMA_NAME(t2.object_id) + N'.' + t2.name referenced_table_name,
fk.is_not_trusted, fk.delete_referential_action_desc on_delete, fk.update_referential_action_desc on_update
FROM sys.foreign_keys fk
INNER JOIN sys.tables t1 ON fk.parent_object_id=t1.object_id
INNER JOIN sys.tables t2 ON fk.referenced_object_id=t2.object_id
ORDER BY 1,2

-- Better FOREIGN KEY script - courtesy of Gustavo Rubio on StackOverflow - http://stackoverflow.com/a/18929992
SELECT  obj.name AS FK_NAME,
    sch.name AS [schema_name],
    tab1.name AS [table],
    col1.name AS [column],
    tab2.name AS [referenced_table],
    col2.name AS [referenced_column]
FROM sys.foreign_key_columns fkc
INNER JOIN sys.objects obj
    ON obj.object_id = fkc.constraint_object_id
INNER JOIN sys.tables tab1
    ON tab1.object_id = fkc.parent_object_id
INNER JOIN sys.schemas sch
    ON tab1.schema_id = sch.schema_id
INNER JOIN sys.columns col1
    ON col1.column_id = parent_column_id AND col1.object_id = tab1.object_id
INNER JOIN sys.tables tab2
    ON tab2.object_id = fkc.referenced_object_id
INNER JOIN sys.columns col2
    ON col2.column_id = referenced_column_id AND col2.object_id = tab2.object_id

-- INFORMATION_SCHEMA (warning: MS says these may not be accurate from SQL 2005 onward)
-- table constraints & total # of tables overall health check
SELECT 'TABLES' object, COUNT(*) #
FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_TYPE='BASE TABLE'
UNION ALL
SELECT CONSTRAINT_TYPE, COUNT(*) # 
FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS 
GROUP BY CONSTRAINT_TYPE

-- foreign key constraints, this is empty in third-party databases :)
SELECT * FROM INFORMATION_SCHEMA.REFERENTIAL_CONSTRAINTS

-- columns
SELECT * FROM INFORMATION_SCHEMA.COLUMNS

-- sp_help procedures
EXEC sp_help 'Sales.SalesOrderDetail'
EXEC sp_helpconstraint 'Sales.SalesOrderDetail'
EXEC sp_check_constraints_rowset 'CK_SalesOrderDetail_OrderQty'

-- you can view the definition of INFORMATION_SCHEMA views and system procedures to see underlying structure of system tables