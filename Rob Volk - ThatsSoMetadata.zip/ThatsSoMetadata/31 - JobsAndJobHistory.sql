USE msdb;

-- jobs
SELECT * FROM sysjobs WHERE enabled=1

-- job steps
SELECT j.name job_name, s.* 
FROM sysjobs j
INNER JOIN dbo.sysjobsteps s ON j.job_id=s.job_id
WHERE j.enabled=1

SELECT j.name job_name, h.* 
FROM sysjobs j
INNER JOIN dbo.sysjobhistory h ON j.job_id=h.job_id
WHERE j.enabled=1

