use msdb;

-- look at backup history
select * from backupset;

-- look at restore history
select * from restorehistory;

-- link them to get details of DB restore
select rh.destination_database_name, bs.database_name, rh.restore_date, bs.type, bs.backup_size
, mf.physical_device_name
from restorehistory rh
inner join backupset bs on rh.backup_set_id=bs.backup_set_id
inner join backupmediafamily mf on bs.media_set_id=mf.media_set_id

-- backup history - pre demo backup
select bs.database_name, bs.type, bs.backup_size, bs.backup_finish_date, mf.physical_device_name
from backupset bs 
inner join backupmediafamily mf on bs.media_set_id=mf.media_set_id
where bs.backup_finish_date>GETDATE()-1;

-- backup history - pre demo backup
select bs.database_name, bs.type, bs.backup_size, bs.backup_finish_date
, DATEDIFF(SECOND,bs.backup_start_date, bs.backup_finish_date) seconds
from backupset bs 
inner join backupmediafamily mf on bs.media_set_id=mf.media_set_id
where bs.backup_finish_date>GETDATE()-1;

alter database AdventureWorks_Large set recovery full;

backup database AdventureWorks_Large to disk='C:\Volk\AdventureWorksLarge_DEMO.bak' 
with init, checksum;

select bs.database_name, bs.type, bs.backup_size, bs.backup_finish_date, mf.physical_device_name
from backupset bs 
inner join backupmediafamily mf on bs.media_set_id=mf.media_set_id
where bs.backup_finish_date>GETDATE()-1;

backup database AdventureWorks_Large to disk='C:\Volk\AdventureWorksLarge_DEMO.dif' 
with differential, init, checksum;

select bs.database_name, bs.type, bs.backup_size, bs.backup_finish_date, mf.physical_device_name
from backupset bs 
inner join backupmediafamily mf on bs.media_set_id=mf.media_set_id
where bs.backup_finish_date>GETDATE()-1;

backup log AdventureWorks_Large to disk='C:\Volk\AdventureWorksLarge_DEMO.trn' 
with init, checksum;

select bs.database_name, bs.type, bs.backup_size, bs.backup_finish_date, mf.physical_device_name
from backupset bs 
inner join backupmediafamily mf on bs.media_set_id=mf.media_set_id
where bs.backup_finish_date>GETDATE()-1;
