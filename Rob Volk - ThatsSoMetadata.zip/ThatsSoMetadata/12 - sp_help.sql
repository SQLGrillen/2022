use AdventureWorks;

-- sp_help

-- DB
exec sp_helpdb;
exec sp_helpdb 'AdventureWorks';
exec sp_helpdb 'AdventureWorks_Large';
-- object
exec sp_help 'Sales.SalesOrderDetail';
exec sp_help 'uspGetBillOfMaterials';
exec sp_help 'Sales.vSalesOrderDetail'

-- sp_helptext
exec sp_helptext 'uspGetBillOfMaterials';
exec sp_helptext 'Sales.vSalesOrderDetail';
