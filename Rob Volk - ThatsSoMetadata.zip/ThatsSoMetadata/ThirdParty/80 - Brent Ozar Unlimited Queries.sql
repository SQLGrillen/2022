-- Brent Ozar Unlimited First Responder Kit: https://www.brentozar.com/responder/

exec sp_blitzcache

EXEC sp_Blitz 
EXEC sp_BlitzIndex
