use AdventureWorks;

select DB_NAME(database_id) DB, OBJECT_NAME(object_id) object_name, index_id, user_seeks, user_lookups, user_scans, user_updates, last_user_seek, last_user_scan, last_user_update
from sys.dm_db_index_usage_stats 
where database_id>4
and database_id=db_id('AdventureWorks');

return;

-- access this table
select top 100 * from Sales.SalesOrderHeader;

-- recheck the index usage stats, should see SalesOrderHeader now
select DB_NAME(database_id) DB, OBJECT_NAME(object_id) object_name, index_id, user_seeks, user_scans, user_lookups, user_updates, last_user_seek, last_user_scan, last_user_update
from sys.dm_db_index_usage_stats 
where database_id>4
and database_id=db_id();

-- look for unused/non-read indexes
select DB_NAME(database_id) DB, OBJECT_NAME(object_id) object_name, index_id, user_seeks, user_scans, user_lookups, user_updates, last_user_seek, last_user_scan, last_user_update
from sys.dm_db_index_usage_stats 
where user_lookups+user_seeks+user_scans=0
--and user_updates>0
and database_id>4
and database_id=db_id();
