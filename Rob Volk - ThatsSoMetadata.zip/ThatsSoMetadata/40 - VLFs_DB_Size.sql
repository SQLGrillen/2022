-- restore from standard backup
restore database AdventureWorks_Large from disk='C:\Volk\AdventureWorks2014.bak' with replace;

-- set FULL recovery
alter database AdventureWorks_Large set recovery full;

-- Run Jonathan Kehayias AdventureWorks enlarging script
-- https://www.sqlskills.com/blogs/jonathan/enlarging-the-adventureworks-sample-databases/

-- check size
exec sp_helpdb
exec sp_helpdb 'AdventureWorks';
exec sp_helpdb 'AdventureWorks_Large';

-- check log file stats
select db_name(database_id) DB, * from sys.dm_db_log_stats(db_id('AdventureWorks'))
union all
select  db_name(database_id) DB,* from sys.dm_db_log_stats(db_id('AdventureWorks_Large'));

-- check VLF details
select db_name(database_id) DB, * from sys.dm_db_log_info(db_id('AdventureWorks'))
select db_name(database_id) DB, * from sys.dm_db_log_info(db_id('AdventureWorks_Large'))

-- check allocation units and page counts
select 'AdventureWorks' DB, count(*) allocation_units, sum(total_pages) total_pages from AdventureWorks.sys.allocation_units
union all
select 'AdventureWorks_Large' DB, count(*) allocation_units, sum(total_pages) total_pages  from AdventureWorks_Large.sys.allocation_units

-- compare to find object & index differences
;WITH cte(obj,ind) AS (
SELECT i.object_id, i.index_id FROM AdventureWorks_Large.sys.indexes i
EXCEPT
SELECT i.object_id, i.index_id FROM AdventureWorks.sys.indexes i)
SELECT t.name tbl, i.name idx
FROM cte c 
INNER JOIN AdventureWorks_Large.sys.tables t ON c.obj=t.object_id
INNER JOIN AdventureWorks_Large.sys.indexes i ON t.object_id=i.object_id AND c.ind=i.index_id
