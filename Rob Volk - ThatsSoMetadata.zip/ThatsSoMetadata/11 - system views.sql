use AdventureWorks;

-- system views/DMVs/DMOs

SELECT * FROM sys.schemas

select * from sys.objects order by type_desc, name;

-- schema-bound objects
select o.name object, o.type_desc, o.object_id, s.name schema_, CONCAT(s.name,N'.',o.name) full_name
FROM sys.objects o 
INNER JOIN sys.schemas s ON o.schema_id=s.schema_id
WHERE o.is_ms_shipped=0 AND o.parent_object_id=0
ORDER by o.type_desc, o.name;

-- select type_desc, count(*) objects from sys.objects group by type_desc order by type_desc;

-- more specific
select * from sys.tables;
select * from sys.views;
select * from sys.check_constraints;
select * from sys.foreign_keys;

-- server and database users/principals
SELECT * FROM sys.server_principals

-- database users/principals and permissions
SELECT * FROM sys.database_principals
SELECT * FROM sys.database_permissions 

-- JOINed together for usefulness
SELECT u.name user_name, p.class_desc, p.state_desc, p.permission_name, o.name object
FROM sys.database_principals u
INNER JOIN sys.database_permissions p ON u.principal_id=p.grantee_principal_id
LEFT JOIN sys.all_objects o ON p.major_id=o.object_id

SELECT * FROM sys.server_permissions
