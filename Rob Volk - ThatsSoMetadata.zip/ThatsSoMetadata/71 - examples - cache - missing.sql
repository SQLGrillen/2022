DBCC FREEPROCCACHE;  -- flush procedure cache to get just these plans, NOT IN PRODUCTION!

EXEC master.dbo.sp_BlitzCache 

-- run following twice to ensure cached plan for DMV queries
DROP INDEX IF EXISTS AccountNumber ON Sales.SalesOrderHeaderEnlarged;

SELECT * 
FROM Sales.SalesOrderHeaderEnlarged h
INNER JOIN Sales.SalesOrderDetailEnlarged d on h.SalesOrderID=d.SalesOrderID
WHERE h.AccountNumber='10-4020-000117';

CREATE INDEX AccountNumber ON Sales.SalesOrderHeaderEnlarged(AccountNumber);

SELECT * 
FROM Sales.SalesOrderHeaderEnlarged h
INNER JOIN Sales.SalesOrderDetailEnlarged d on h.SalesOrderID=d.SalesOrderID
WHERE h.AccountNumber='10-4020-000117';

RETURN;

EXEC master.dbo.sp_BlitzCache 

-- Missing Index for specific query (Glenn Berry)

-- Find missing index warnings for cached plans in the current database  (Query 68) (Missing Index Warnings)
-- Note: This query could take some time on a busy instance
SELECT TOP(25) OBJECT_NAME(objectid) AS [ObjectName], 
               cp.objtype, cp.usecounts, cp.size_in_bytes, query_plan
FROM sys.dm_exec_cached_plans AS cp WITH (NOLOCK)
CROSS APPLY sys.dm_exec_query_plan(cp.plan_handle) AS qp
WHERE CAST(query_plan AS NVARCHAR(MAX)) LIKE N'%MissingIndex%'
AND dbid = DB_ID()
ORDER BY cp.usecounts DESC OPTION (RECOMPILE);

