-- Demo sp_whoisactive: http://whoisactive.com/
USE AdventureWorks_Large;

SELECT TOP 100000 *
FROM Sales.SalesOrderDetailEnlarged d
INNER JOIN Sales.SalesOrderHeaderEnlarged h
ON d.SalesOrderID=h.SalesOrderID;

RETURN;
-- End sp_whoisactive demo


-- Missing Index and query plan -- check Jonathan K & Glenn B & Brent O plan queries

DBCC FREEPROCCACHE;  -- flush procedure cache to get just these plans, NOT IN PRODUCTION!

-- run following twice to ensure cached plan for DMV queries
DROP INDEX IF EXISTS AccountNumber ON Sales.SalesOrderHeaderEnlarged;

SELECT * 
FROM Sales.SalesOrderHeaderEnlarged h
INNER JOIN Sales.SalesOrderDetailEnlarged d on h.SalesOrderID=d.SalesOrderID
WHERE h.AccountNumber='10-4020-000117';

CREATE INDEX AccountNumber ON Sales.SalesOrderHeaderEnlarged(AccountNumber);

SELECT * 
FROM Sales.SalesOrderHeaderEnlarged h
INNER JOIN Sales.SalesOrderDetailEnlarged d on h.SalesOrderID=d.SalesOrderID
WHERE h.AccountNumber='10-4020-000117';

RETURN;
-- End Missing Index and query plan


-- generate indexes on columns in foreign key constraints
;WITH cte(objid,colid) AS (
	SELECT parent_object_id, parent_column_id 
	FROM sys.foreign_key_columns 
	EXCEPT 
	SELECT object_id, column_id FROM sys.index_columns)
SELECT FORMATMESSAGE(N'CREATE NONCLUSTERED INDEX %s ON %s.%s(%s);'
, c.name, OBJECT_SCHEMA_NAME(t.object_id), t.name, c.name) AS index_statement
FROM sys.tables t 
INNER JOIN sys.columns c ON t.object_id=c.object_id 
INNER JOIN cte ON c.object_id=cte.objid AND c.column_id=cte.colid
ORDER BY 1;


-- Missing Index details query

-- missing index details
SELECT * 
FROM sys.dm_db_missing_index_details d
INNER JOIN sys.dm_db_missing_index_groups g ON d.index_handle=g.index_handle
INNER JOIN sys.dm_db_missing_index_group_stats gs ON g.index_group_handle=gs.group_handle



-- ****** Dynamic SQL using DMV metadata

-- backup all databases
select 
FORMATMESSAGE(N'backup database %s to disk=''C:\backup\%s_%s.bak'''
,name
,name
,FORMAT(getdate(),'yyyyMMdd'))
from sys.databases 
where name<>'tempdb'
order by name;
